# Plan three AI video shots

Start with one subject, one movement and one camera instruction. Each prompt below is a writing exercise. Replace the subject with material you own or have permission to use.

| Shot | Input | Practice prompt | Review the result |
| --- | --- | --- | --- |
| Text to video | No image | A ceramic cup on a wooden table. Steam rises in morning light. Keep the camera still. | Does the cup remain in place? Can you see the steam without a cut? |
| Photo animation | One photo | Keep the bottle upright. A narrow reflection travels across the glass. Lock the camera. | Pause on the label at the beginning, middle and end. Note any change in lettering. |
| Transition | Two images | Hold the composition as the desk lamp gradually warms from white to amber. | Compare the final frame with your second reference. Record any shift in position. |

## Make a second attempt

Write down the mode, your original prompt, the one detail you changed and where the result first diverged. Change just that detail on the next attempt. For packaging, keep an authorized label file for editing if accurate lettering matters.

Use the [official image-to-video guide](https://freevideoai.app/image-to-video) for upload requirements and the [pricing page](https://freevideoai.app/pricing) for the current credit rules.
